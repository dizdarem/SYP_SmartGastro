import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders,HttpResponse } from '@angular/common/http';
import { Order } from '../models/Order';
import { Observable } from 'rxjs';
import { catchError, retry } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})

export class OrderService {
  hostURL:string='http://178.188.6.194:2432/'
  mealURL:string='RestaurantVerwaltung_WebService/SmartGastro/BestellungGruppiert/filteredMeals'
  drinkURL:string='RestaurantVerwaltung_WebService/SmartGastro/BestellungGruppiert/filteredDrinks'
  postenURL:string="RestaurantVerwaltung_WebService/SmartGastro/BestellungGruppiert/updateBrought";
  constructor(private http:HttpClient) { }

  getWaiterOrders(){

    console.log("calledin db");
  
    return this.http.get<Order[]>(this.hostURL+this.drinkURL,httpOptions);
  

  }
  getKitchenOrders(){
    console.log("called kitchen orders");
    return this.http.get<Order[]>(this.hostURL+this.mealURL,httpOptions);
  }
  postPosten (posten) {
    const requestBody = JSON.stringify(posten);
    console.log(requestBody);
    return this.http.put(this.hostURL+this.postenURL, requestBody,httpOptions)
    .pipe(
      
    );
  }
 
}
const httpOptions = {
  
  headers: new HttpHeaders({
    'Content-Type':  'application/json',
  })
}