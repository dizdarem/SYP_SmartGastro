export class Order{
    idBestellung:number;
    idTisch:number;
    bestellZeit:string;
    postenObject:object;
}