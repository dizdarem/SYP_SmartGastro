import { Component, OnInit } from '@angular/core';
import { Order } from '../../models/Order';
import { OrderService } from '../../services/order.service';

@Component({
  selector: 'app-kitchen-orders',
  templateUrl: './kitchen-orders.component.html',
  styleUrls: ['./kitchen-orders.component.css']
})
export class KitchenOrdersComponent implements OnInit {

  orders: Order[];
  constructor(private orderService:OrderService) { }

  ngOnInit() {
    
    this.orderService.getKitchenOrders().subscribe(orders =>{
      this.orders=orders;
    })
    

}
postenGebracht(idBestellung,idPosten){

  var postenJSON={
    "idBestellung":idBestellung,
    "idPosten":idPosten,
    "brought":true
  }
  this.orderService.postPosten(postenJSON).subscribe(
    response => {console.log(response)
    this.ngOnInit();
    });;
}
}
