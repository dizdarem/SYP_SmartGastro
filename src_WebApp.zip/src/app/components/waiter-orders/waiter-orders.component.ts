import { Component, OnInit } from '@angular/core';
import { Order } from '../../models/Order';
import { OrderService } from '../../services/order.service';

@Component({
  selector: 'app-waiter-orders',
  templateUrl: './waiter-orders.component.html',
  styleUrls: ['./waiter-orders.component.css']
})
export class WaiterOrdersComponent implements OnInit {

  orders: Order[];
  constructor(private orderService:OrderService) { }

  ngOnInit() {
    
    this.orderService.getWaiterOrders().subscribe(orders =>{
      this.orders=orders;
    })

}
postenGebracht(idBestellung,idPosten){

  var postenJSON={
    "idBestellung":idBestellung,
    "idPosten":idPosten,
    "brought":true
  }
  this.orderService.postPosten(postenJSON).subscribe(
    response => {console.log(response)
    this.ngOnInit();
    });;
}
}
