import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { KitchenOrdersComponent } from './components/kitchen-orders/kitchen-orders.component';
import { WaiterOrdersComponent } from './components/waiter-orders/waiter-orders.component';

const routes: Routes = [
  { path: 'kitchen-orders', component: KitchenOrdersComponent, data: { title: 'Kitchen Orders' } },
  { path: 'waiter-orders', component: WaiterOrdersComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
