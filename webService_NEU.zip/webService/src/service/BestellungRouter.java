package service;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import app.ConsoleLog;
import dal.Database;
import bll.Bestellung;

@Path("/Bestellung")
public class BestellungRouter {

	@Context
	private UriInfo context;

	public BestellungRouter() {
	}

	@POST
	@Consumes({ MediaType.APPLICATION_JSON })
	public Response addBestellung(String strBestellung) throws Exception {
		Response.ResponseBuilder response = Response.status(Response.Status.OK);

		try {
			Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd'_'HH:mm:ss").create();
			Bestellung best = gson.fromJson(strBestellung, Bestellung.class);
			Database.newInstance().addBestellung(best);
			response.entity("bestellung added");
		} catch (Exception e) {
			response.status(Response.Status.BAD_REQUEST);
			response.entity("[ERROR] " + e.getMessage());
			e.printStackTrace();
			// ConsoleLog.logToConsole(e.getMessage());
		}
		ConsoleLog.logToConsole("POST bestellung called, got following JSON: " + strBestellung);
		return response.build();
	}
}
