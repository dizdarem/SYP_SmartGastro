package service;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.POST;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import com.google.gson.Gson;

import app.ConsoleLog;
import dal.Database;

@Path("/Tisch")
public class TischRouter {
	@Context
	private UriInfo context;

	public TischRouter() {
	}

	@POST
	@Consumes({ MediaType.APPLICATION_JSON })
	public Response addTisch(Integer tischId) {
		Response.ResponseBuilder response = Response.status(Response.Status.OK);

		try {
			Database.newInstance().addTisch(tischId);
			response.entity("tisch added");
		} catch (Exception e) {
			response.status(Response.Status.BAD_REQUEST);
			response.entity("[ERROR] " + e.getMessage());
			e.printStackTrace();
		}
		ConsoleLog.logToConsole("POST tisch called");
		return response.build();
	}
	
	@GET
	@Path("/ids") 
	@Produces({MediaType.APPLICATION_JSON})
	public Response getTischIds() {
		Response.ResponseBuilder response = Response.status(Response.Status.OK);
        try {
            Database db = Database.newInstance();
            response.entity(new Gson().toJson(db.getTischIds()));
        } catch (Exception e) {
            response.status(Response.Status.BAD_REQUEST);
            response.entity("[ERROR] " + e.getMessage());
        }
        
        ConsoleLog.logToConsole("Get Tisch ids called");
        return response.build();
	}

}
