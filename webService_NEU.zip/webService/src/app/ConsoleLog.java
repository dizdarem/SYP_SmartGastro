package app;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class ConsoleLog {
	public static void logToConsole(String message) {
		String timestamp = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss").format(Calendar.getInstance().getTime());
		System.out.println("[INFO] " + timestamp + " - " + message);
	}
}
