package bll;

public enum ProduktTyp {
	getraenk, gericht, beilage, dessert
}
